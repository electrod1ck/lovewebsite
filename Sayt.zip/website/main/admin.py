from django.contrib import admin
from .models import Logo


admin.site.register(Logo)
