from django.db import models

class Logo(models.Model):
    image = models.ImageField(upload_to='logos/')

    def __str__(self):
        return self.image.name

class Account(models.Model):
    username = models.CharField(max_length=150, unique=True)
    passport_serial = models.CharField(max_length=4)
    passport_number = models.CharField(max_length=6)
    password = models.CharField(max_length=128)
    secretword = models.CharField(max_length=150)

    def __str__(self):
        return self.username