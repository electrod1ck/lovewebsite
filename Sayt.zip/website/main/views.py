# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .models import Logo
from .forms import AccountCreationForm, CustomUserCreationForm
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_protect

def home(request):
    logo = Logo.objects.first()
    return render(request, 'home.html', {'logo': logo})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {username}!')
                return redirect('home')
            else:
                messages.error(request, 'Неверное имя пользователя или пароль.')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = AuthenticationForm()
    logo = Logo.objects.first()
    return render(request, 'login.html', {'form': form, 'logo': logo})

@csrf_protect
def signin(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            passport_combined = form.cleaned_data['passport_combined']
            password = form.cleaned_data['password']
            secretword = form.cleaned_data['secretword']

            try:
                user = User.objects.create_user(username=username, password=password)
                user.first_name = passport_combined[:4]
                user.last_name = passport_combined[4:]
                user.email = secretword
                user.save()

                login(request, user)
                messages.success(request, 'Аккаунт успешно создан! Вы вошли в систему.')
                return redirect('home')
            except Exception as e:
                messages.error(request, f'Ошибка при создании аккаунта: {e}')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = CustomUserCreationForm()

    logo = Logo.objects.first()
    return render(request, 'main/templates/signin.html', {'form': form, 'logo': logo})

def open_account(request):
    from .forms import AccountCreationForm
    if request.method == 'POST':
        form = AccountCreationForm(request.POST)
        if form.is_valid():
            currency = form.cleaned_data['currency']
            account_type = form.cleaned_data['account_type']
            # Сохранение информации о счете в базу данных (если нужна отдельная модель для счетов)
            return render(request, 'success.html', {'currency': currency, 'account_type': account_type})
    else:
        form = AccountCreationForm()

    return render(request, 'wallet.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "Вы вышли из системы.")
    return redirect('home')

def wallet(request):
    logo = Logo.objects.first()
    return render(request, 'wallet.html', {'logo': logo})